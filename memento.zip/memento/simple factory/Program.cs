﻿// See https://aka.ms/new-console-template for more information



using memento;


var chess = new Chess() { Move = "Horse Moves L step"};
var chessManager = new ChessManager();
chessManager.AddMememento(chess.CreateState());
Console.WriteLine(chess.Move);

chess.Move = "soldier moves 1 step";
chessManager.AddMememento(chess.CreateState());
Console.WriteLine(chess.Move);

chess.Move = "Queen moves";
chessManager.AddMememento(chess.CreateState());
Console.WriteLine(chess.Move);

Console.WriteLine("-------------------------");
chess.Undo(chessManager.GetMemento());
chess.Undo(chessManager.GetMemento());
Console.WriteLine(chess.Move);

chess.Undo(chessManager.GetMemento());
Console.WriteLine(chess.Move);

