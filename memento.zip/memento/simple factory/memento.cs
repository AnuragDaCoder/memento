﻿using Newtonsoft.Json;

namespace memento
{
    //Originator 
    class Chess 
    {
        public string? Move;

        public Memento CreateState()
        {
            return new Memento(Move!);
        }

        public void Undo(Memento memento)
        {
            Move = memento.Move;
        }

    }

    //Memento
    public class Memento
    {
        public string Move { get { return move; } }

        private string ? move;

        public Memento(string move)
        {
            this.move = move;
        }

    }

    //Creator
    class ChessManager
    {
        Stack<Memento> mementos = new Stack<Memento>();

        public void AddMememento(Memento state)
        {
            mementos.Push(state);
        }

        public Memento GetMemento()
        {
            return mementos.Pop();
        }
    }
}
